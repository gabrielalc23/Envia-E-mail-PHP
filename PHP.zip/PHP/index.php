<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados</title>
</head>

<body>
    <?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    require './PHPMailer/src/PHPMailer.php';
    require './PHPMailer/src/SMTP.php';
    require './PHPMailer/src/Exception.php';

    // Recupere os dados do formulário
    $nome        = $_GET['nome'];
    $nasc        = $_GET['nasc'];
    $genero      = $_GET['genero'];
    $formacao    = $_GET['formacao'];
    $profissoes  = $_GET['profissoes'];
    $cpf         = $_GET['cpf'];
    $email       = $_GET['email'];
    $tel         = $_GET['tel'];
    $cel         = $_GET['cel'];
    $linkedin    = $_GET['linkedin'];
    $logradouto  = $_GET['logra'];
    $bairro      = $_GET['bairro'];
    $numero      = $_GET['num'];
    $estado      = $_GET['estado'];
    $complemento = $_GET['complemento'];

    // Crie o corpo do e-mail
    $mensagem = "
        <p><strong>Nome:</strong> $nome</p>
        <p><strong>Data de Nascimento:</strong> $nasc</p>
        <p><strong>Gênero:</strong> $genero</p>
        <p><strong>Formação:</strong> $formacao</p>
        <p><strong>Profissões:</strong> $profissoes</p>
        <p><strong>CPF:</strong> $cpf</p>
        <p><strong>E-mail:</strong> $email</p>
        <p><strong>Telefone:</strong> $tel</p>
        <p><strong>Celular:</strong> $cel</p>
        <p><strong>LinkedIn:</strong> $linkedin</p>
        <p><strong>Endereço:</strong> $logradouto, $numero, $bairro, $estado, $complemento</p>
    ";

    // Instancie o objeto PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host       = '@gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'Gabriel Lopes';
        $mail->Password   = '230407';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // TLS é recomendado
        $mail->Port       = 587; // Porta SMTP

        // Remetente e destinatário
        $mail->setFrom('Gabriellopes.campos23@gmail.com', 'Gabriel Lopes');
        $mail->addAddress('Gabriellopes230407@gmail.com', 'Gabriel Campos');

        // Conteúdo do e-mail
        $mail->isHTML(true);
        $mail->Subject = 'Dados do Formulário';
        $mail->Body    = $mensagem;

        // Enviar o e-mail
        $mail->send();
        echo 'E-mail enviado com sucesso';
    } catch (Exception $e) {
        echo "Erro ao enviar o e-mail: {$mail->ErrorInfo}";
    }
    ?>
</body>

</html>
